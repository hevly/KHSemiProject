package camp.web.statics;

public class Statics {

	public static int RECORD_COUNT_PER_PAGE = 10;
	public static int NAVI_COUNT_PER_PAGE = 10;
}
